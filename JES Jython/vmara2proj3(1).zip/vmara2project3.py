#Valo Mara
#vmara2
#French flag collage

def blueColor(picture1): #sets first image to blue

  for x in range (0, getWidth(picture1), 1):
    for y in range (0, getHeight(picture1), 1):
      p = getPixel(picture1, x, y)
      r = getRed(p)
      g = getGreen(p)
      b = getBlue(p)
      
      avg = int(r*.299 + g*.587 + b*.114)
      
      setRed(p, avg)
      setGreen(p, avg)
      setBlue(p, 255)
  
  return picture1
  
def bandwColor(picture2):  #sets second image to white and black image

  for x in range (0, getWidth(picture2), 1):
    for y in range (0, getHeight(picture2), 1):
      p = getPixel(picture2, x, y)
      r = getRed(p)
      g = getGreen(p)
      b = getBlue(p)
      
      avg = int(r*.299 + g*.587 + b*.114)
      
      if (avg > 170):
        setRed(p, 255)
        setGreen(p, 255)
        setBlue(p, 255)
      else:
        setRed(p, 0)
        setGreen(p, 0)
        setBlue(p, 0)
  
  return picture2
  
def redColor(picture3): #sets third picture to red

  for x in range (0, getWidth(picture3), 1):
    for y in range (0, getHeight(picture3), 1):
      p = getPixel(picture3, x, y)
      r = getRed(p)
      g = getGreen(p)
      b = getBlue(p)
      
      avg = int(r*.299 + g*.587 + b*.114)
      
      setRed(p, 255)
      setGreen(p, avg)
      setBlue(p, avg)
      
  return picture3
      
def crop(changepic, picture1, picture2, picture3): #crops picture to skinniest width and shortest height and changes color

  blueColor(picture1)
  bandwColor(picture2)
  redColor(picture3)
  
  shortest = 0 
  skinniest = 0
  
  if getHeight(picture1) <= getHeight(picture2) and getHeight(picture1) <= getHeight(picture3):
    shortest = picture1
  elif getHeight(picture2) <= getHeight(picture1) and getHeight(picture2)<= getHeight(picture3):
    shortest = picture2
  else:
    shortest = picture3
    
  if getWidth(picture1) <= getWidth(picture2) and getWidth(picture1) <= getWidth(picture3):
    skinniest = picture1
  elif getWidth(picture2) <= getWidth(picture1) and getWidth(picture2) <= getWidth(picture3):
    skinniest = picture2
  else: 
    skinniest = picture3
    
  outputpic = makeEmptyPicture(getWidth(skinniest), getHeight(shortest))
  
  for x in range(0, getWidth(outputpic), 1):
    for y in range(0, getHeight(outputpic), 1):
      origpixel = getPixel(changepic, x, y)
      color = getColor(origpixel)
      newpixel = getPixel(outputpic, x, y)
      setColor(newpixel, color)
  return outputpic
      
def collage(picture1, picture2, picture3): #makes the edited pictures into a collage
  
  croppic1 = crop(picture1, picture1, picture2, picture3)
  croppic2 = crop(picture2, picture1, picture2, picture3)
  croppic3 = crop(picture3, picture1, picture2, picture3)
  
  collagepic = makeEmptyPicture(getWidth(croppic1)*3, getHeight(croppic1))
  
  for x in range(0, getWidth(croppic1), 1):
    for y in range(0, getHeight(croppic1), 1):
      inputpix = getPixel(croppic1, x, y)
      color = getColor(inputpix)
      outputpix = getPixel(collagepic, x, y)
      setColor(outputpix, color)
      
  for x in range(0, getWidth(croppic2), 1):
    for y in range(0, getHeight(croppic2), 1):
      inputpix = getPixel(croppic2, x, y)
      color = getColor(inputpix)
      outputpix = getPixel(collagepic, x + getWidth(croppic1), y)
      setColor(outputpix, color)

  for x in range(0, getWidth(croppic3), 1):
    for y in range(0, getHeight(croppic3), 1):
      inputpix = getPixel(croppic3, x, y)
      color = getColor(inputpix)
      outputpix = getPixel(collagepic, x + getWidth(croppic1)*2, y)
      setColor(outputpix, color)
      
  return collagepic
      
fname = pickAFile()
print(fname)

directorypos = fname.rfind("/")
if (directorypos == -1):
  directypos = fname.rfind("\\")
  
dirname = fname[0:directorypos + 1]

print(dirname)

eiffeltowerfile = dirname + "eiffeltower.jpg"
winefile = dirname + "wine.jpg"
baguettefile = dirname + "baguette.jpg"

print(eiffeltowerfile)
print(winefile)
print(baguettefile)

pic1 = makePicture(eiffeltowerfile)
pic2 = makePicture(baguettefile)
pic3 = makePicture(winefile)

newPic = collage(pic1, pic2, pic3)
show(newPic)